Juju Client
-----------

A simple synchronous python client for the juju-core websocket api.
Compatible with python2 and python3.


See documentation at http://python-jujuclient.readthedocs.org
