============
Installation
============

At the command line::

    $ pip install juju-bundlelib
