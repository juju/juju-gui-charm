========
Usage
========

To use the Juju Python library for handling bundles in a project::

    import jujubundlelib
